package com.tsx.lagfix

/** Chạy trong tiến trình shell do Shizuku cấp (quyền ADB). */
class UserService : IUserService.Stub() {
    override fun destroy() { System.exit(0) }
    override fun exec(cmd: String): String = try {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Exception) { e.message ?: "" }
}
