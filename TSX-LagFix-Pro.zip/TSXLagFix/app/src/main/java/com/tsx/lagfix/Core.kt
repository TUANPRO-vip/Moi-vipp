package com.tsx.lagfix

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Sao lưu/khôi phục thiết lập, nhật ký, chẩn đoán, đo ping. */
class Core(private val ctx: Context) {
    private val logFile = File(ctx.filesDir, "tsx_core.log")
    private val bk = ctx.getSharedPreferences("bk", 0)

    fun log(s: String) {
        try {
            if (logFile.length() > 100_000) logFile.writeText(logFile.readText().takeLast(50_000))
            logFile.appendText("[${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}] $s\n")
        } catch (e: Exception) {}
    }

    fun readLog(): String = try {
        logFile.readText().takeLast(6000).ifBlank { "Nhật ký chưa có dữ liệu." }
    } catch (e: Exception) { "Nhật ký chưa có dữ liệu." }

    fun clearLog() { try { logFile.writeText("") } catch (e: Exception) {} }

    /** Lưu giá trị gốc (chỉ lần đầu), đặt giá trị mới rồi đọc lại để xác nhận. */
    fun setS(ns: String, key: String, value: String): Boolean {
        if (!Sh.ready) return false
        val id = "$ns|$key"
        if (!bk.contains(id)) {
            val old = Sh.run("settings get $ns $key").trim()
            if (old.isEmpty()) { log("WARN không đọc được $id"); return false }
            bk.edit().putString(id, old).apply()
        }
        Sh.run("settings put $ns $key $value")
        val now = Sh.run("settings get $ns $key").trim()
        val ok = now == value || (now.toDoubleOrNull() != null && now.toDoubleOrNull() == value.toDoubleOrNull())
        log(if (ok) "OK $id=$value" else "WARN $id yêu cầu=$value, đọc lại=$now")
        return ok
    }

    private fun put(ns: String, key: String, old: String) =
        Sh.run(if (old == "null") "settings delete $ns $key" else "settings put $ns $key $old")

    /** Trả một thiết lập về giá trị gốc đã sao lưu. */
    fun restoreKey(ns: String, key: String) {
        val id = "$ns|$key"
        val old = bk.getString(id, null) ?: return
        put(ns, key, old); bk.edit().remove(id).apply(); log("RESTORE $id")
    }

    fun restoreAll(): Int {
        var n = 0
        bk.all.forEach { (id, v) ->
            val p = id.split("|")
            if (p.size == 2 && v is String) { put(p[0], p[1], v); log("RESTORE $id"); n++ }
        }
        bk.edit().clear().apply()
        return n
    }

    fun diag(): String = buildString {
        fun sec(t: String, b: String) { append("— $t —\n").append(b.trim()).append("\n\n") }
        sec("THIẾT BỊ", "${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\n" +
            "${Build.DISPLAY}\nShizuku: ${if (Sh.ready) "sẵn sàng" else "chưa kết nối"}")
        val keys = listOf("MemTotal", "MemAvailable", "Cached", "SwapTotal", "SwapFree")
        sec("RAM", try {
            File("/proc/meminfo").readLines().filter { l -> keys.any { l.startsWith("$it:") } }.joinToString("\n")
        } catch (e: Exception) { "Không đọc được" })
        sec("CPU", "Hardware: ${Build.HARDWARE}\nABI: ${Build.SUPPORTED_ABIS.firstOrNull()}\n" +
            "Số nhân: ${Runtime.getRuntime().availableProcessors()}\nTải: " +
            (try { File("/proc/loadavg").readText() } catch (e: Exception) { "không đọc được" }))
        val st = StatFs(Environment.getDataDirectory().path)
        val g = 1024.0 * 1024 * 1024
        sec("LƯU TRỮ", "Trống %.1f / %.1f GB".format(st.availableBytes / g, st.totalBytes / g))
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        sec("PIN / NHIỆT", "Mức pin: ${b?.getIntExtra("level", 0)}%\n" +
            "Nhiệt độ: ${(b?.getIntExtra("temperature", 0) ?: 0) / 10f}°C\nĐiện áp: ${b?.getIntExtra("voltage", 0)} mV")
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val nc = cm.getNetworkCapabilities(cm.activeNetwork)
        sec("MẠNG", when {
            nc == null -> "Không có mạng"
            nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi • ~${nc.linkDownstreamBandwidthKbps / 1000} Mbps"
            nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Dữ liệu di động • ~${nc.linkDownstreamBandwidthKbps / 1000} Mbps"
            else -> "Khác"
        })
        append("Ứng dụng không thay đổi giới hạn nhiệt và không tắt bảo vệ nhiệt.")
    }

    fun ping(): String {
        fun one(h: String): Long = try {
            val t = System.nanoTime()
            Socket().use { it.connect(InetSocketAddress(h, 443), 2500) }
            (System.nanoTime() - t) / 1_000_000
        } catch (e: Exception) { -1L }
        val r = listOf("1.1.1.1" to "Cloudflare", "8.8.8.8" to "Google").map { (h, n) ->
            val v = (1..3).map { one(h) }.filter { it >= 0 }
            n to (if (v.isEmpty()) -1L else v.sum() / v.size)
        }
        return r.joinToString("\n") { (n, ms) ->
            if (ms < 0) "$n: không kết nối được"
            else "$n: $ms ms " + when { ms < 50 -> "(tốt)"; ms < 100 -> "(ổn)"; else -> "(cao, dễ lag)" }
        } + "\n\nĐây là ping tới máy chủ công cộng, không phải máy chủ Free Fire."
    }
}
