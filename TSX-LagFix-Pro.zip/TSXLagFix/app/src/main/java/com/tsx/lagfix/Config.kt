package com.tsx.lagfix

// ====== SỬA 3 DÒNG NÀY THEO FIREBASE CỦA BẠN ======
const val PROJECT_ID = "DAN_PROJECT_ID"                 // projectId trong cấu hình Firebase
const val API_KEY = "DAN_API_KEY"                       // apiKey trong cấu hình Firebase
const val CONTACT_URL = "https://zalo.me/SDT_CUA_BAN"   // link liên hệ admin (Zalo/Telegram...)

// Đặt true khi muốn bắt buộc nhập key để dùng app. Hiện đang TẮT (app mở thẳng vào chức năng).
const val KEY_REQUIRED = false
