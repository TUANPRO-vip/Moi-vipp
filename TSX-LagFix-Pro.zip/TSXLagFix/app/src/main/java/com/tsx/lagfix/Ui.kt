package com.tsx.lagfix

import android.app.ActivityManager
import android.content.ComponentName
import android.content.ContentResolver
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import rikka.shizuku.Shizuku

val BG = Color(0xFF07040F)
val SURF = Color(0xFF140B28)
val SURF_ON = Color(0xFF2A1458)
val PUR = Color(0xFF9B5CFF)
val PUR2 = Color(0xFF5B21D6)
val DIM = Color(0xFFA99BC8)
const val NEED = "Cần bật Shizuku để dùng tính năng này"
val FF = listOf("com.dts.freefireth", "com.dts.freefiremax")

data class Stat(val used: Float, val tot: Float, val cpu: Int, val hz: Int)

class Fx(
    val key: String, val ic: ImageVector, val t: String, val d: String, val pro: Boolean,
    val on: () -> String, val off: () -> String, val g: String
)

// ================= UI components =================
/** Hiệu ứng nhấn: nảy nhẹ (spring) */
fun Modifier.pressFx(f: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pr by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pr) 0.95f else 1f, spring(dampingRatio = 0.45f, stiffness = 600f), label = "sc")
    Modifier.scale(sc).clickable(interactionSource = src, indication = null) { f() }
}

@Composable
fun Tx(s: String, sz: Int = 14, c: Color = Color.White, w: FontWeight = FontWeight.Normal,
       m: Modifier = Modifier, a: TextAlign? = null) =
    Text(s, m, color = c, fontSize = sz.sp, fontWeight = w, textAlign = a)

@Composable
fun Glass(m: Modifier = Modifier, c: @Composable BoxScope.() -> Unit) {
    val s = RoundedCornerShape(16.dp)
    Box(m.clip(s).background(SURF).border(1.dp, Brush.linearGradient(listOf(PUR, Color(0x335B21D6))), s), content = c)
}

@Composable
fun Gauge(label: String, big: String, small: String, frac: Float) {
    Box(Modifier.size(92.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = 8.dp.toPx()
            val tl = Offset(w / 2, w / 2)
            val sz = Size(size.width - w, size.height - w)
            drawArc(Color(0x33FFFFFF), 135f, 270f, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
            drawArc(Brush.linearGradient(listOf(PUR2, PUR)), 135f, 270f * frac.coerceIn(0f, 1f), false, tl, sz,
                style = Stroke(w, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Tx(label, 10, DIM); Tx(big, 17, w = FontWeight.Bold); Tx(small, 9, DIM)
        }
    }
}

/** Một hàng chức năng: icon tím + tên + công tắc ON/OFF */
@Composable
fun FxRow(ic: ImageVector, t: String, d: String, init: Boolean, f: (Boolean) -> Boolean) {
    var v by remember { mutableStateOf(init) }
    val a by animateFloatAsState(if (v) 1f else 0f, tween(300), label = "a")
    val s = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().pressFx { if (f(!v)) v = !v }.clip(s)
            .background(lerp(SURF, SURF_ON, a))
            .border(1.dp, lerp(Color(0x335B21D6), PUR, a), s).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(PUR.copy(alpha = 0.15f + 0.25f * a)),
            contentAlignment = Alignment.Center) {
            Icon(ic, null, tint = PUR, modifier = Modifier.size(22.dp).scale(1f + 0.15f * a))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Tx(t, 15, w = FontWeight.SemiBold); Tx(d, 11, DIM) }
        Switch(v, { if (f(it)) v = it }, colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White, checkedTrackColor = PUR,
            uncheckedThumbColor = DIM, uncheckedTrackColor = Color(0xFF1E1236)))
    }
}

@Composable
fun GameChip(t: String, sub: String, sel: Boolean, m: Modifier, f: () -> Unit) {
    val a by animateFloatAsState(if (sel) 1f else 0f, tween(250), label = "g")
    val s = RoundedCornerShape(14.dp)
    Column(m.pressFx(f).clip(s).background(lerp(SURF, SURF_ON, a))
        .border(1.dp, lerp(Color(0x335B21D6), PUR, a), s).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Tx(t, 14, w = FontWeight.SemiBold); Tx(sub, 11, DIM)
    }
}

@Composable
fun Splash(done: () -> Unit) {
    var s by remember { mutableStateOf(false) }
    val p by animateFloatAsState(if (s) 1f else 0f, tween(1700), label = "p")
    LaunchedEffect(Unit) { s = true; delay(2000); done() }
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(270.dp).clip(CircleShape))
        Spacer(Modifier.height(18.dp))
        Tx("TỐI ƯU - MƯỢT MÀ - CHIẾN THẮNG", 12, DIM)
        Spacer(Modifier.height(28.dp))
        Tx("Đang khởi động...", 13, PUR)
        Spacer(Modifier.height(8.dp))
        Box(Modifier.width(220.dp).height(4.dp).clip(CircleShape).background(Color(0x33FFFFFF))) {
            Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(Brush.horizontalGradient(listOf(PUR2, PUR))))
        }
    }
}


@Composable
fun ToolTile(ic: ImageVector, t: String, m: Modifier, f: () -> Unit) {
    val s = RoundedCornerShape(14.dp)
    Row(m.pressFx(f).clip(s).background(SURF).border(1.dp, Color(0x335B21D6), s).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(ic, null, tint = PUR, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp)); Tx(t, 13, w = FontWeight.SemiBold)
    }
}
