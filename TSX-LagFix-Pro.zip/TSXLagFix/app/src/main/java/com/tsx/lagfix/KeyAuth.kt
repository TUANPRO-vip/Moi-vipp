package com.tsx.lagfix

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlin.math.ceil

/** Kiểm tra key qua Firestore REST. Giờ dùng giờ máy chủ (header Date) để chống chỉnh giờ. */
object KeyAuth {
    data class Res(val ok: Boolean, val msg: String, val key: String = "", val exp: Long = 0L, val net: Boolean = true)

    private const val DAY = 86_400_000L
    private val FORMAT = Regex("^TSX-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$")

    private fun base(key: String) =
        "https://firestore.googleapis.com/v1/projects/$PROJECT_ID/databases/(default)/documents/keys/$key"

    fun deviceId(ctx: Context): String {
        val id = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        return MessageDigest.getInstance("SHA-256").digest("tsx$id".toByteArray())
            .take(8).joinToString("") { "%02x".format(it) }
    }

    fun daysLeft(r: Res): Long = if (r.exp == 0L) -1 else ceil((r.exp - System.currentTimeMillis()) / DAY.toDouble()).toLong()

    /** Trả về (mã HTTP, nội dung, giờ máy chủ) hoặc null nếu lỗi mạng. */
    private fun http(patch: Boolean, url: String, body: String?): Triple<Int, String, Long>? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        if (patch) {
            c.requestMethod = "POST"                         // HttpURLConnection không hỗ trợ PATCH
            c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
            c.setRequestProperty("Content-Type", "application/json")
            c.doOutput = true
            c.outputStream.use { it.write(body!!.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        Triple(code, text, c.getHeaderFieldDate("Date", System.currentTimeMillis()))
    } catch (e: Exception) { null }

    fun login(ctx: Context, raw: String): Res {
        if (PROJECT_ID.startsWith("DAN_")) return Res(false, "Chưa cấu hình máy chủ key (sửa Config.kt)")
        val key = raw.trim().uppercase()
        if (!FORMAT.matches(key)) return Res(false, "Key không đúng định dạng (TSX-XXXX-XXXX-XXXX)")
        val dev = deviceId(ctx)
        val (code, body, now) = http(false, "${base(key)}?key=$API_KEY", null)
            ?: return Res(false, "Không kết nối được máy chủ", net = false)
        if (code == 404) return Res(false, "Key không tồn tại")
        if (code != 200) return Res(false, "Lỗi máy chủ ($code)")

        val f = JSONObject(body).getJSONObject("fields")
        val days = f.optJSONObject("days")?.optString("integerValue")?.toLongOrNull() ?: 0L
        var act = f.optJSONObject("activatedAt")?.optString("integerValue")?.toLongOrNull() ?: 0L
        val device = f.optJSONObject("device")?.optString("stringValue") ?: ""
        if (f.optJSONObject("locked")?.optBoolean("booleanValue") == true) return Res(false, "Key đã bị khóa")
        if (device.isNotEmpty() && device != dev) return Res(false, "Key đã được dùng trên thiết bị khác")
        if (act != 0L && days > 0 && now >= act + days * DAY) return Res(false, "Key đã hết hạn")

        if (device.isEmpty()) { // kích hoạt lần đầu: gắn thiết bị
            val a = if (act != 0L) act else now
            val json = """{"fields":{"device":{"stringValue":"$dev"},"activatedAt":{"integerValue":"$a"}}}"""
            val r = http(true, "${base(key)}?updateMask.fieldPaths=device&updateMask.fieldPaths=activatedAt&key=$API_KEY", json)
                ?: return Res(false, "Không kết nối được máy chủ", net = false)
            if (r.first != 200) return Res(false, "Không kích hoạt được key (mã ${r.first})")
            act = a
        }
        return Res(true, "OK", key, if (days > 0) act + days * DAY else 0L)
    }

    /** Đăng nhập tự động bằng key đã lưu; mất mạng thì cho dùng tiếp tối đa 24 giờ. */
    fun auto(ctx: Context, p: SharedPreferences): Res {
        val k = p.getString("key", "") ?: ""
        if (k.isEmpty()) return Res(false, "")
        val r = login(ctx, k)
        val now = System.currentTimeMillis()
        if (r.ok) { p.edit().putLong("exp", r.exp).putLong("ok", now).apply(); return r }
        if (!r.net) {
            val exp = p.getLong("exp", 0L)
            if (now - p.getLong("ok", 0L) in 0..DAY && (exp == 0L || now < exp)) return Res(true, "offline", k, exp)
        }
        return r
    }
}
