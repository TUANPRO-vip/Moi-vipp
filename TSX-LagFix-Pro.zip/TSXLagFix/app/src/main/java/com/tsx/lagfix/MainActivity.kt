package com.tsx.lagfix

import android.app.ActivityManager
import android.content.ComponentName
import android.content.ContentResolver
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import rikka.shizuku.Shizuku

private val BG = Color(0xFF07040F)
private val SURF = Color(0xFF140B28)
private val SURF_ON = Color(0xFF2A1458)
private val PUR = Color(0xFF9B5CFF)
private val PUR2 = Color(0xFF5B21D6)
private val DIM = Color(0xFFA99BC8)
private const val NEED = "Cần bật Shizuku để dùng tính năng này"
private val FF = listOf("com.dts.freefireth", "com.dts.freefiremax")

data class Stat(val used: Float, val tot: Float, val cpu: Int, val hz: Int)

private class Fx(
    val key: String, val ic: ImageVector, val t: String, val d: String, val pro: Boolean,
    val on: () -> String, val off: () -> String
)

// ================= UI components =================
/** Hiệu ứng nhấn: nảy nhẹ (spring) */
fun Modifier.pressFx(f: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pr by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pr) 0.95f else 1f, spring(dampingRatio = 0.45f, stiffness = 600f), label = "sc")
    Modifier.scale(sc).clickable(interactionSource = src, indication = null) { f() }
}

@Composable
fun Tx(s: String, sz: Int = 14, c: Color = Color.White, w: FontWeight = FontWeight.Normal,
       m: Modifier = Modifier, a: TextAlign? = null) =
    Text(s, m, color = c, fontSize = sz.sp, fontWeight = w, textAlign = a)

@Composable
fun Glass(m: Modifier = Modifier, c: @Composable BoxScope.() -> Unit) {
    val s = RoundedCornerShape(16.dp)
    Box(m.clip(s).background(SURF).border(1.dp, Brush.linearGradient(listOf(PUR, Color(0x335B21D6))), s), content = c)
}

@Composable
fun Gauge(label: String, big: String, small: String, frac: Float) {
    Box(Modifier.size(92.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = 8.dp.toPx()
            val tl = Offset(w / 2, w / 2)
            val sz = Size(size.width - w, size.height - w)
            drawArc(Color(0x33FFFFFF), 135f, 270f, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
            drawArc(Brush.linearGradient(listOf(PUR2, PUR)), 135f, 270f * frac.coerceIn(0f, 1f), false, tl, sz,
                style = Stroke(w, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Tx(label, 10, DIM); Tx(big, 17, w = FontWeight.Bold); Tx(small, 9, DIM)
        }
    }
}

/** Một hàng chức năng: icon tím + tên + công tắc ON/OFF */
@Composable
fun FxRow(ic: ImageVector, t: String, d: String, init: Boolean, f: (Boolean) -> Boolean) {
    var v by remember { mutableStateOf(init) }
    val a by animateFloatAsState(if (v) 1f else 0f, tween(300), label = "a")
    val s = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().pressFx { if (f(!v)) v = !v }.clip(s)
            .background(lerp(SURF, SURF_ON, a))
            .border(1.dp, lerp(Color(0x335B21D6), PUR, a), s).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(PUR.copy(alpha = 0.15f + 0.25f * a)),
            contentAlignment = Alignment.Center) {
            Icon(ic, null, tint = PUR, modifier = Modifier.size(22.dp).scale(1f + 0.15f * a))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Tx(t, 15, w = FontWeight.SemiBold); Tx(d, 11, DIM) }
        Switch(v, { if (f(it)) v = it }, colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White, checkedTrackColor = PUR,
            uncheckedThumbColor = DIM, uncheckedTrackColor = Color(0xFF1E1236)))
    }
}

@Composable
fun GameChip(t: String, sub: String, sel: Boolean, m: Modifier, f: () -> Unit) {
    val a by animateFloatAsState(if (sel) 1f else 0f, tween(250), label = "g")
    val s = RoundedCornerShape(14.dp)
    Column(m.pressFx(f).clip(s).background(lerp(SURF, SURF_ON, a))
        .border(1.dp, lerp(Color(0x335B21D6), PUR, a), s).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Tx(t, 14, w = FontWeight.SemiBold); Tx(sub, 11, DIM)
    }
}

@Composable
fun Splash(done: () -> Unit) {
    var s by remember { mutableStateOf(false) }
    val p by animateFloatAsState(if (s) 1f else 0f, tween(1700), label = "p")
    LaunchedEffect(Unit) { s = true; delay(2000); done() }
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(270.dp).clip(CircleShape))
        Spacer(Modifier.height(18.dp))
        Tx("TỐI ƯU - MƯỢT MÀ - CHIẾN THẮNG", 12, DIM)
        Spacer(Modifier.height(28.dp))
        Tx("Đang khởi động...", 13, PUR)
        Spacer(Modifier.height(8.dp))
        Box(Modifier.width(220.dp).height(4.dp).clip(CircleShape).background(Color(0x33FFFFFF))) {
            Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(Brush.horizontalGradient(listOf(PUR2, PUR))))
        }
    }
}

// ================= Activity =================
class MainActivity : ComponentActivity() {
    private val shz = mutableIntStateOf(0) // 0 chưa chạy, 1 cần cấp quyền, 2 sẵn sàng
    private var busy by mutableStateOf<String?>(null)
    private var stat by mutableStateOf(Stat(0f, 1f, -1, 60))
    private var prevT = 0L
    private var prevI = 0L
    private var binding = false

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            Sh.svc = IUserService.Stub.asInterface(b); shz.intValue = 2
        }
        override fun onServiceDisconnected(n: ComponentName?) { Sh.svc = null; binding = false; shz.intValue = 1 }
    }
    private val onBinder = Shizuku.OnBinderReceivedListener { check() }
    private val onDead = Shizuku.OnBinderDeadListener { Sh.svc = null; binding = false; shz.intValue = 0 }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> check() }

    private fun check() {
        if (!Shizuku.pingBinder()) { shz.intValue = 0; return }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { shz.intValue = 1; return }
        if (Sh.svc == null && !binding) {
            binding = true
            Shizuku.bindUserService(
                Shizuku.UserServiceArgs(ComponentName(packageName, UserService::class.java.name))
                    .processNameSuffix("sh").version(1).daemon(false), conn)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
        setContent { App() }
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
    }

    // ---------- helpers ----------
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun sh(c: String) = Sh.run(c)

    private fun go(label: String, after: (() -> Unit)? = null, f: () -> String): Boolean {
        if (busy != null) return false
        busy = label
        Thread {
            val r = try { f() } catch (e: Exception) { "Lỗi: ${e.message}" }
            runOnUiThread { busy = null; toast(r); after?.invoke() }
        }.start()
        return true
    }

    private fun installed(p: String) = packageManager.getLaunchIntentForPackage(p) != null
    private fun launch(p: String) =
        packageManager.getLaunchIntentForPackage(p)?.let { startActivity(it) } ?: toast("Chưa cài game này")

    private fun hzList(): List<Int> =
        windowManager.defaultDisplay.supportedModes.map { it.refreshRate.roundToInt() }.distinct().sorted()

    private fun availMb(): Long {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.availMem shr 20
    }

    private fun cpuPct(): Int {
        if (!Sh.ready) return -1
        val f = sh("head -1 /proc/stat").trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (f.size < 5) return -1
        val t = f.take(8).sum(); val i = f[3] + f[4]
        val r = if (prevT == 0L || t == prevT) 0 else (100 - (i - prevI) * 100 / (t - prevT)).toInt()
        prevT = t; prevI = i
        return r.coerceIn(0, 100)
    }

    private fun readStat(): Stat {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val g = 1024f * 1024f * 1024f
        return Stat((mi.totalMem - mi.availMem) / g, mi.totalMem / g, cpuPct(),
            windowManager.defaultDisplay.refreshRate.roundToInt())
    }

    // ---------- engine ----------
    private fun killBgApi() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName }.distinct().filter { it != packageName }
            .forEach { am.killBackgroundProcesses(it) }
    }

    private fun ramClean(): String {
        val a = availMb()
        if (Sh.ready) sh("am kill-all; pm trim-caches 999G") else killBgApi()
        Thread.sleep(900)
        return "Đã giải phóng ~${maxOf(0, availMb() - a)} MB RAM" + if (Sh.ready) " + dọn cache" else ""
    }

    private fun killApps(): String {
        if (!Sh.ready) { killBgApi(); return "Đã tắt app nền (cơ bản). Bật Shizuku để tắt sâu hơn" }
        val ime = Settings.Secure.getString(contentResolver, "default_input_method")?.substringBefore('/')
        val home = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName
        val keep = (listOfNotNull(packageName, "moe.shizuku.privileged.api", ime, home) + FF).joinToString("|")
        sh("for p in \$(pm list packages -3 | cut -d: -f2); do case \$p in $keep) ;; *) am force-stop \$p;; esac; done; am kill-all")
        return "Đã tắt ứng dụng chạy nền"
    }

    private fun lockHz(hz: Int): String {
        sh("settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz")
        return "Đã khóa ${hz}Hz (tùy máy hỗ trợ)"
    }

    private fun unlockHz(): String {
        sh("settings delete system min_refresh_rate; settings delete system peak_refresh_rate")
        return "Đã mở khóa tần số quét"
    }

    private fun boostFps(): String {
        val c = StringBuilder("settings put global low_power 0;")
        FF.forEach {
            c.append("cmd game mode performance $it; am set-standby-bucket $it active;")
            c.append("dumpsys deviceidle whitelist +$it; cmd appops set $it RUN_ANY_IN_BACKGROUND allow;")
        }
        sh(c.toString())
        return "Đã bật chế độ hiệu năng cao cho Free Fire"
    }

    private fun unboost(): String {
        sh(FF.joinToString(";") { "cmd game mode standard $it" })
        return "Đã trở về chế độ thường"
    }

    private fun dropFps(): String {
        sh("am kill-all; pm trim-caches 999G; settings put global low_power 0")
        try { ContentResolver.setMasterSyncAutomatically(false) } catch (e: Exception) {}
        return "Đã giảm tải hệ thống, hạn chế tụt khung hình"
    }

    private fun syncOn(): String {
        try { ContentResolver.setMasterSyncAutomatically(true) } catch (e: Exception) {}
        return "Đã tắt chế độ giảm drop FPS"
    }

    private fun ramOpt(): String {
        val c = StringBuilder("am kill-all;")
        FF.forEach { c.append("am set-standby-bucket $it active; dumpsys deviceidle whitelist +$it;") }
        sh(c.toString())
        return "Đã ưu tiên tài nguyên cho Free Fire"
    }

    private fun deep(): String {
        val ins = FF.filter { installed(it) }
        if (ins.isEmpty()) return "Chưa cài Free Fire"
        ins.forEach { sh("cmd package compile -m speed -f $it") }
        return "Đã tối ưu sâu mã game (ART)"
    }

    private fun anim(v: String): String {
        sh("settings put global window_animation_scale $v; settings put global transition_animation_scale $v;" +
            "settings put global animator_duration_scale $v")
        return "Đã đặt animation ${v}x"
    }

    private val fx = listOf(
        Fx("boost", Icons.Filled.KeyboardArrowUp, "Tăng FPS", "Chế độ hiệu năng cao cho game", true,
            { boostFps() }, { unboost() }),
        Fx("drop", Icons.Filled.Refresh, "Giảm Drop FPS", "Hạn chế tụt khung hình", true,
            { dropFps() }, { syncOn() }),
        Fx("lock", Icons.Filled.Lock, "Khóa FPS", "Giữ tần số quét cao, ổn định", true,
            { lockHz(hzList().last()) }, { unlockHz() }),
        Fx("ram", Icons.Filled.Delete, "Dọn RAM", "Giải phóng bộ nhớ, dọn cache", false,
            { ramClean() }, { "Đã tắt" }),
        Fx("opt", Icons.Filled.CheckCircle, "Tối ưu RAM", "Ưu tiên tài nguyên cho game", true,
            { ramOpt() }, { "Đã tắt" }),
        Fx("kill", Icons.Filled.Close, "Tắt ứng dụng chạy nền", "Giảm tải hệ thống, tăng hiệu suất", false,
            { killApps() }, { "Đã tắt" }),
        Fx("deep", Icons.Filled.Build, "Tối ưu sâu game (PRO)", "Biên dịch mã game, mất 1-3 phút", true,
            { deep() }, { "Đã tắt" }),
        Fx("dnd", Icons.Filled.Notifications, "Tắt thông báo", "Không làm phiền khi chơi", true,
            { sh("cmd notification set_dnd priority"); "Đã bật không làm phiền" },
            { sh("cmd notification set_dnd off"); "Đã tắt không làm phiền" }),
        Fx("bright", Icons.Filled.Info, "Tắt tự động sáng", "Giữ độ sáng cố định", true,
            { sh("settings put system screen_brightness_mode 0"); "Đã tắt tự động sáng" },
            { sh("settings put system screen_brightness_mode 1"); "Đã bật tự động sáng" }),
        Fx("anim", Icons.Filled.Settings, "Giảm hiệu ứng hệ thống", "Animation 0.5x cho mượt", true,
            { anim("0.5") }, { anim("1") }),
        Fx("svc", Icons.Filled.Share, "Tắt dịch vụ không cần thiết", "Bluetooth, NFC, đồng bộ", true,
            { sh("svc bluetooth disable; svc nfc disable"); try { ContentResolver.setMasterSyncAutomatically(false) } catch (e: Exception) {}; "Đã tắt dịch vụ thừa" },
            { sh("svc bluetooth enable; svc nfc enable"); try { ContentResolver.setMasterSyncAutomatically(true) } catch (e: Exception) {}; "Đã bật lại dịch vụ" })
    )

    private fun toggle(f: Fx, on: Boolean): Boolean {
        if (f.pro && !Sh.ready) { toast(NEED); return false }
        val ok = go(if (on) "Đang bật ${f.t}..." else "Đang tắt ${f.t}...") { if (on) f.on() else f.off() }
        if (ok) getSharedPreferences("fx", 0).edit().putBoolean(f.key, on).apply()
        return ok
    }

    private fun play(p: String) {
        if (!installed(p)) { toast("Chưa cài game này"); return }
        go("Đang mở game...", { launch(p) }) { ramClean() }
    }

    private fun shizukuAction() = when (shz.intValue) {
        0 -> packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
            ?: toast("Hãy cài và khởi động Shizuku trước")
        1 -> Shizuku.requestPermission(1)
        else -> toast("Shizuku đã sẵn sàng ✔")
    }

    // ---------- screens ----------
    @Composable
    fun App() {
        var splash by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) { while (true) { stat = withContext(Dispatchers.IO) { readStat() }; delay(2000) } }
        Box(Modifier.fillMaxSize().background(BG)) {
            if (splash) Splash { splash = false } else Main()
            busy?.let {
                Box(Modifier.fillMaxSize().background(Color(0xCC000000)).clickable(enabled = true, onClick = {}),
                    contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = PUR); Spacer(Modifier.height(12.dp)); Tx(it, 14)
                    }
                }
            }
        }
    }

    @Composable
    fun Pill() {
        val (t, c) = when (shz.intValue) {
            2 -> "SHIZUKU ●" to Color(0xFF4ADE80)
            1 -> "CẤP QUYỀN" to Color(0xFFFBBF24)
            else -> "BẬT SHIZUKU" to Color(0xFFF87171)
        }
        Box(Modifier.pressFx { shizukuAction() }.clip(RoundedCornerShape(20.dp))
            .border(1.dp, c, RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 6.dp)) {
            Tx(t, 11, c, FontWeight.Bold)
        }
    }

    @Composable
    fun Main() {
        val st = stat
        val prefs = getSharedPreferences("fx", 0)
        var sel by remember { mutableIntStateOf(0) }
        val names = listOf("Free Fire", "Free Fire MAX")
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.logo), null, Modifier.size(44.dp).clip(CircleShape))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("TSX", style = TextStyle(brush = Brush.linearGradient(listOf(Color(0xFFE2CCFF), PUR)),
                            fontSize = 26.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic))
                        Tx("Android ${android.os.Build.VERSION.RELEASE} • ${android.os.Build.MODEL}", 11, DIM)
                    }
                    Spacer(Modifier.weight(1f)); Pill()
                }
                Glass(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), Arrangement.SpaceEvenly) {
                        Gauge("RAM", "%.1f GB".format(st.used), "/ %.1f GB".format(st.tot), st.used / st.tot)
                        Gauge("CPU", if (st.cpu < 0) "--" else "${st.cpu}%",
                            if (st.cpu < 0) "Cần Shizuku" else "Sử dụng", if (st.cpu < 0) 0f else st.cpu / 100f)
                        Gauge("HZ", "${st.hz}", "Màn hình", st.hz / (hzList().lastOrNull() ?: st.hz).toFloat())
                    }
                }
                Tx("TÍNH NĂNG", 12, PUR, FontWeight.Bold, Modifier.padding(top = 4.dp))
                fx.forEach { f -> FxRow(f.ic, f.t, f.d, prefs.getBoolean(f.key, false)) { on -> toggle(f, on) } }
            }
            Column(Modifier.fillMaxWidth().background(SURF).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    names.forEachIndexed { i, n ->
                        GameChip(n, if (installed(FF[i])) "Đã cài đặt" else "Chưa cài", sel == i, Modifier.weight(1f)) { sel = i }
                    }
                }
                val s = RoundedCornerShape(28.dp)
                Box(Modifier.fillMaxWidth().height(56.dp).pressFx { play(FF[sel]) }.clip(s)
                    .background(Brush.horizontalGradient(listOf(SURF_ON, Color(0xFF3B1A78))))
                    .border(1.dp, PUR, s), contentAlignment = Alignment.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.PlayArrow, null, tint = PUR, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(6.dp))
                        Tx("CHƠI ${names[sel].uppercase()}", 16, w = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
