package com.tsx.lagfix

import android.app.ActivityManager
import android.content.pm.ApplicationInfo
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.text.font.FontFamily
import android.content.ComponentName
import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import rikka.shizuku.Shizuku

private val ANIM = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")

class MainActivity : ComponentActivity() {
    private val shz = mutableIntStateOf(0) // 0 chưa chạy, 1 cần cấp quyền, 2 sẵn sàng
    private var busy by mutableStateOf<String?>(null)
    private var stat by mutableStateOf(Stat(0f, 1f, -1, 60))
    private var ver by mutableIntStateOf(0)
    private var dlgT by mutableStateOf<String?>(null)
    private var dlgB by mutableStateOf("")
    private var pick by mutableIntStateOf(0) // 1: chọn app để dừng, 2: cài đặt nhanh
    private var out = ""
    private var prevT = 0L
    private var prevI = 0L
    private var binding = false
    private val core by lazy { Core(this) }
    private var auth by mutableIntStateOf(0) // 0 đang kiểm tra, 1 cần đăng nhập, 2 đã đăng nhập
    private var authMsg by mutableStateOf("")
    private var info by mutableStateOf("")
    private var loginBusy by mutableStateOf(false)
    private var lastCheck = 0L
    private val ap by lazy { getSharedPreferences("auth", 0) }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            Sh.svc = IUserService.Stub.asInterface(b); shz.intValue = 2
        }
        override fun onServiceDisconnected(n: ComponentName?) { Sh.svc = null; binding = false; shz.intValue = 1 }
    }
    private val onBinder = Shizuku.OnBinderReceivedListener { check() }
    private val onDead = Shizuku.OnBinderDeadListener { Sh.svc = null; binding = false; shz.intValue = 0 }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> check() }

    private fun check() {
        if (!Shizuku.pingBinder()) { shz.intValue = 0; return }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { shz.intValue = 1; return }
        if (Sh.svc == null && !binding) {
            binding = true
            Shizuku.bindUserService(
                Shizuku.UserServiceArgs(ComponentName(packageName, UserService::class.java.name))
                    .processNameSuffix("sh").version(1).daemon(false), conn)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
        setContent { App() }
        startAuth()
    }

    override fun onResume() {
        super.onResume()
        if (KEY_REQUIRED && auth == 2 && System.currentTimeMillis() - lastCheck > 600_000) recheck()
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
    }

    // ---------- helpers ----------
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun sh(c: String) = Sh.run(c)

    private fun go(label: String, after: (() -> Unit)? = null, f: () -> String): Boolean {
        if (busy != null) return false
        busy = label
        Thread {
            val r = try { f() } catch (e: Exception) { "Lỗi: ${e.message}" }
            core.log("$label → $r")
            runOnUiThread { busy = null; if (r.isNotEmpty()) toast(r); after?.invoke() }
        }.start()
        return true
    }

    private fun installed(p: String) = packageManager.getLaunchIntentForPackage(p) != null
    private fun launch(p: String) =
        packageManager.getLaunchIntentForPackage(p)?.let { startActivity(it) } ?: toast("Chưa cài game này")
    private fun openSet(a: String) = try { startActivity(Intent(a)) } catch (e: Exception) { toast("Máy không hỗ trợ mục này") }

    private fun hzList(): List<Int> =
        windowManager.defaultDisplay.supportedModes.map { it.refreshRate.roundToInt() }.distinct().sorted()

    private fun availMb(): Long {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.availMem shr 20
    }

    private fun cpuPct(): Int {
        if (!Sh.ready) return -1
        val f = sh("head -1 /proc/stat").trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (f.size < 5) return -1
        val t = f.take(8).sum(); val i = f[3] + f[4]
        val r = if (prevT == 0L || t == prevT) 0 else (100 - (i - prevI) * 100 / (t - prevT)).toInt()
        prevT = t; prevI = i
        return r.coerceIn(0, 100)
    }

    private fun readStat(): Stat {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val g = 1024f * 1024f * 1024f
        return Stat((mi.totalMem - mi.availMem) / g, mi.totalMem / g, cpuPct(),
            windowManager.defaultDisplay.refreshRate.roundToInt())
    }

    private fun userApps(): List<Pair<String, String>> =
        packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM == 0 && it.activityInfo.packageName != packageName }
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }.sortedBy { it.first.lowercase() }

    // ---------- engine ----------
    private fun keepList(): String {
        val ime = Settings.Secure.getString(contentResolver, "default_input_method")?.substringBefore('/')
        val home = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName
        return (listOfNotNull(packageName, "moe.shizuku.privileged.api", ime, home) + FF).joinToString("|")
    }

    private fun forThirdParty(cmd: String) =
        sh("for p in \$(pm list packages -3 | cut -d: -f2); do case \$p in ${keepList()}) ;; *) $cmd;; esac; done")

    private fun killBgApi() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName }.distinct().filter { it != packageName }
            .forEach { am.killBackgroundProcesses(it) }
    }

    private fun ramClean(): String {
        val a = availMb()
        cacheDir.listFiles()?.forEach { it.deleteRecursively() }
        if (Sh.ready) sh("am kill-all; pm trim-caches 999G") else killBgApi()
        Thread.sleep(900)
        return "Đã giải phóng ~${maxOf(0, availMb() - a)} MB RAM" + if (Sh.ready) " + dọn cache" else ""
    }

    private fun killApps(): String {
        if (!Sh.ready) { killBgApi(); return "Đã tắt app nền (cơ bản). Bật Shizuku để tắt sâu hơn" }
        forThirdParty("am force-stop \$p"); sh("am kill-all")
        return "Đã tắt ứng dụng chạy nền"
    }

    private fun restrictBg(on: Boolean): String {
        if (!Sh.ready) return NEED
        forThirdParty("cmd appops set \$p RUN_ANY_IN_BACKGROUND ${if (on) "deny" else "default"}")
        return if (on) "Đã giới hạn chạy nền (thông báo app khác có thể trễ)" else "Đã gỡ giới hạn chạy nền"
    }

    private fun lockHz(hz: Int): String {
        val ok = core.setS("system", "min_refresh_rate", "$hz") and core.setS("system", "peak_refresh_rate", "$hz")
        return if (ok) "Đã khóa ${hz}Hz (tùy máy hỗ trợ)" else "Đã gửi lệnh khóa ${hz}Hz nhưng chưa xác nhận được"
    }

    private fun restore(vararg k: String, ns: String = "global", msg: String): String {
        k.forEach { core.restoreKey(ns, it) }; return msg
    }

    private fun boostFps(): String {
        core.setS("global", "low_power", "0")
        val c = StringBuilder()
        FF.forEach {
            c.append("cmd game mode performance $it; am set-standby-bucket $it active;")
            c.append("dumpsys deviceidle whitelist +$it; cmd appops set $it RUN_ANY_IN_BACKGROUND allow;")
        }
        sh(c.toString())
        return "Đã bật chế độ hiệu năng cao cho Free Fire"
    }

    private fun unboost(): String {
        sh(FF.joinToString(";") { "cmd game mode standard $it" })
        return restore("low_power", msg = "Đã trở về chế độ thường")
    }

    private fun dropFps(): String {
        sh("am kill-all; pm trim-caches 999G")
        core.setS("global", "low_power", "0")
        try { ContentResolver.setMasterSyncAutomatically(false) } catch (e: Exception) {}
        return "Đã giảm tải hệ thống, hạn chế tụt khung hình"
    }

    private fun undrop(): String {
        try { ContentResolver.setMasterSyncAutomatically(true) } catch (e: Exception) {}
        return restore("low_power", msg = "Đã tắt chế độ giảm drop FPS")
    }

    private fun ramOpt(): String {
        val c = StringBuilder("am kill-all;")
        FF.forEach { c.append("am set-standby-bucket $it active; dumpsys deviceidle whitelist +$it;") }
        sh(c.toString())
        return "Đã ưu tiên tài nguyên cho Free Fire"
    }

    private fun deep(): String {
        val ins = FF.filter { installed(it) }
        if (ins.isEmpty()) return "Chưa cài Free Fire"
        ins.forEach { sh("cmd package compile -m speed -f $it") }
        return "Đã tối ưu sâu mã game (ART)"
    }

    private fun anim(v: String): String {
        val ok = ANIM.map { core.setS("global", it, v) }.all { it }
        return if (ok) "Đã đặt animation ${v}x" else "Đã gửi lệnh nhưng chưa xác nhận được"
    }

    private fun full(): String {
        val s = FF.joinToString(";") { "cmd game mode standard $it" }
        sh("cmd notification set_dnd off; svc bluetooth enable; svc nfc enable; $s")
        restrictBg(false)
        try { ContentResolver.setMasterSyncAutomatically(true) } catch (e: Exception) {}
        getSharedPreferences("sysoff", 0).let { p -> p.all.keys.forEach { sh("pm enable $it") }; p.edit().clear().apply() }
        getSharedPreferences("fx", 0).edit().clear().apply()
        return "Đã khôi phục ${core.restoreAll()} thiết lập về giá trị gốc"
    }

    private fun dnsFast(): String {
        val best = core.fastestDns() ?: return "Không đo được DNS (kiểm tra mạng)"
        val ok = core.setS("global", "private_dns_specifier", best.first) and core.setS("global", "private_dns_mode", "hostname")
        return if (ok) "Đã đặt DNS ${best.first} (${best.second} ms)" else "Máy không cho đặt DNS"
    }

    private fun refreshNet(): String {
        sh("w=\$(settings get global wifi_on); m=\$(settings get global mobile_data); " +
            "if [ \"\$w\" = \"1\" ]; then svc wifi disable; sleep 2; svc wifi enable; " +
            "elif [ \"\$m\" = \"1\" ]; then svc data disable; sleep 2; svc data enable; fi")
        return "Đã làm mới kết nối mạng"
    }

    /** Cấu hình tự động theo dung lượng RAM (giống ý tưởng chọn 4/6/8/12/16GB trong script Windows). */
    private fun applyPreset(): String {
        if (!Sh.ready) return NEED
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val gb = mi.totalMem / 1_000_000_000.0
        val keys = when {
            gb <= 4.5 -> listOf("drop", "anim", "freeze", "scan", "dns", "blur", "log")
            gb <= 8.5 -> listOf("drop", "anim", "dns", "blur")
            else -> listOf("boost", "lock", "dns")
        }
        val p = getSharedPreferences("fx", 0).edit()
        var n = 0
        fx.filter { it.key in keys }.forEach { f -> try { f.on(); p.putBoolean(f.key, true); n++ } catch (e: Exception) {} }
        p.apply()
        return "Đã áp dụng $n tính năng phù hợp máy %.1f GB RAM".format(gb)
    }

    // Ứng dụng hệ thống KHÔNG cho tắt (an toàn)
    private val NOKILL = listOf("android", "com.android.", "com.google.android.gms", "com.google.android.gsf",
        "com.google.android.inputmethod", "com.google.android.packageinstaller", "com.google.android.permissioncontroller",
        "com.google.android.apps.messaging", "com.google.android.dialer", "com.google.android.webview",
        "com.google.android.setupwizard", "com.qualcomm", "com.mediatek", "com.bbk.launcher2", "com.vivo.launcher",
        "com.vivo.permissionmanager", "com.iqoo.secure", "com.vivo.abe", "com.vivo.setupwizard", "com.sec.android.app.launcher")

    private fun sysApps(): List<Pair<String, String>> {
        val home = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName
        val ime = Settings.Secure.getString(contentResolver, "default_input_method")?.substringBefore('/')
        val live = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { r ->
                val p = r.activityInfo.packageName
                r.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM != 0 &&
                    p != packageName && p != home && p != ime && NOKILL.none { p.startsWith(it) }
            }.map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
        val saved = getSharedPreferences("sysoff", 0).all.map { (k, v) -> v.toString() to k } // app đã tắt vẫn hiện để bật lại
        return (live + saved).distinctBy { it.second }.sortedBy { it.first.lowercase() }
    }

    private val fx = listOf(
        Fx("boost", Icons.Filled.KeyboardArrowUp, "Tăng FPS", "Chế độ hiệu năng cao cho game", true,
            { boostFps() }, { unboost() }, "HIỆU NĂNG"),
        Fx("drop", Icons.Filled.Refresh, "Giảm Drop FPS", "Hạn chế tụt khung hình", true,
            { dropFps() }, { undrop() }, "HIỆU NĂNG"),
        Fx("lock", Icons.Filled.Lock, "Khóa FPS", "Giữ tần số quét cao, ổn định", true,
            { lockHz(hzList().last()) }, { restore("min_refresh_rate", "peak_refresh_rate", ns = "system", msg = "Đã mở khóa tần số quét") }, "HIỆU NĂNG"),
        Fx("anim", Icons.Filled.Settings, "Giảm hiệu ứng hệ thống", "Animation 0.5x cho mượt", true,
            { anim("0.5") }, { restore(*ANIM.toTypedArray(), msg = "Đã khôi phục animation") }, "HIỆU NĂNG"),
        Fx("anim0", Icons.Filled.Clear, "Tắt hoàn toàn hiệu ứng", "Animation 0x, phản hồi tức thì", true,
            { anim("0") }, { restore(*ANIM.toTypedArray(), msg = "Đã khôi phục animation") }, "HIỆU NĂNG"),
        Fx("blur", Icons.Filled.Favorite, "Tắt hiệu ứng làm mờ", "Android 12+, giảm tải GPU", true,
            { if (core.setS("global", "disable_window_blurs", "1")) "Đã tắt hiệu ứng làm mờ" else "Máy chưa hỗ trợ mục này" },
            { restore("disable_window_blurs", msg = "Đã bật lại hiệu ứng làm mờ") }, "HIỆU NĂNG"),
        Fx("freeze", Icons.Filled.Star, "Đóng băng ứng dụng nền", "Android 12+, có thể cần khởi động lại", true,
            { if (core.setS("global", "cached_apps_freezer", "enabled")) "Đã bật đóng băng app nền" else "Máy chưa hỗ trợ mục này" },
            { restore("cached_apps_freezer", msg = "Đã trả về mặc định") }, "HIỆU NĂNG"),

        Fx("ram", Icons.Filled.Delete, "Dọn RAM", "Giải phóng bộ nhớ, dọn cache", false,
            { ramClean() }, { "Đã tắt" }, "BỘ NHỚ"),
        Fx("opt", Icons.Filled.CheckCircle, "Tối ưu RAM", "Ưu tiên tài nguyên cho game", true,
            { ramOpt() }, { "Đã tắt" }, "BỘ NHỚ"),
        Fx("kill", Icons.Filled.Close, "Tắt ứng dụng chạy nền", "Giảm tải hệ thống, tăng hiệu suất", false,
            { killApps() }, { "Đã tắt" }, "BỘ NHỚ"),
        Fx("restrict", Icons.Filled.Warning, "Giới hạn app chạy nền", "Chặn app nền khi chơi, thông báo có thể trễ", true,
            { restrictBg(true) }, { restrictBg(false) }, "BỘ NHỚ"),
        Fx("deep", Icons.Filled.Build, "Tối ưu sâu game (PRO)", "Biên dịch mã game, mất 1-3 phút", true,
            { deep() }, { "Đã tắt" }, "BỘ NHỚ"),
        Fx("art", Icons.Filled.Done, "Tối ưu ART hệ thống", "Chạy tối ưu nền của Android ngay", true,
            { sh("cmd package bg-dexopt-job"); "Đã yêu cầu hệ thống tối ưu ứng dụng" }, { "Đã tắt" }, "BỘ NHỚ"),
        Fx("junk", Icons.Filled.Delete, "Dọn rác sâu", "Cache ngoài, thumbnail, log hệ thống", true,
            { core.deepJunk() }, { "Đã tắt" }, "BỘ NHỚ"),

        Fx("dns", Icons.Filled.Send, "DNS nhanh (tự chọn tốt nhất)", "Đo Cloudflare, Google, Quad9 rồi chọn nhanh nhất", true,
            { dnsFast() },
            { restore("private_dns_mode", "private_dns_specifier", msg = "Đã khôi phục DNS") }, "MẠNG"),
        Fx("scan", Icons.Filled.Search, "Tắt quét mạng nền", "Dừng quét Wi-Fi/Bluetooth, data nền", true,
            { val k = listOf("wifi_scan_always_enabled", "ble_scan_always_enabled", "mobile_data_always_on")
              if (k.map { core.setS("global", it, "0") }.all { it }) "Đã tắt quét mạng nền" else "Đã gửi lệnh, một số mục chưa xác nhận" },
            { restore("wifi_scan_always_enabled", "ble_scan_always_enabled", "mobile_data_always_on", msg = "Đã khôi phục") }, "MẠNG"),
        Fx("net", Icons.Filled.Refresh, "Làm mới kết nối mạng", "Tắt/bật Wi-Fi hoặc data để xóa kết nối cũ", true,
            { refreshNet() }, { "Đã tắt" }, "MẠNG"),

        Fx("dnd", Icons.Filled.Notifications, "Tắt thông báo", "Không làm phiền khi chơi", true,
            { sh("cmd notification set_dnd priority"); "Đã bật không làm phiền" },
            { sh("cmd notification set_dnd off"); "Đã tắt không làm phiền" }, "HỆ THỐNG"),
        Fx("bright", Icons.Filled.Info, "Tắt tự động sáng", "Giữ độ sáng cố định", true,
            { if (core.setS("system", "screen_brightness_mode", "0")) "Đã tắt tự động sáng" else "Chưa xác nhận được" },
            { restore("screen_brightness_mode", ns = "system", msg = "Đã khôi phục độ sáng tự động") }, "HỆ THỐNG"),
        Fx("svc", Icons.Filled.Share, "Tắt dịch vụ không cần thiết", "Bluetooth, NFC, đồng bộ", true,
            { sh("svc bluetooth disable; svc nfc disable"); try { ContentResolver.setMasterSyncAutomatically(false) } catch (e: Exception) {}; "Đã tắt dịch vụ thừa" },
            { sh("svc bluetooth enable; svc nfc enable"); try { ContentResolver.setMasterSyncAutomatically(true) } catch (e: Exception) {}; "Đã bật lại dịch vụ" }, "HỆ THỐNG"),
        Fx("log", Icons.Filled.Edit, "Giảm ghi nhật ký nền", "Tắt log khởi chạy app, xóa bộ đệm log", true,
            { sh("logcat -c"); if (core.setS("global", "activity_starts_logging_enabled", "0")) "Đã giảm ghi nhật ký" else "Đã xóa bộ đệm log" },
            { restore("activity_starts_logging_enabled", msg = "Đã khôi phục ghi nhật ký") }, "HỆ THỐNG")
    )

    private fun showText(t: String, label: String, f: () -> String) {
        go(label, { dlgT = t; dlgB = out }) { out = f(); "" }
    }

    private val tools: List<Triple<ImageVector, String, () -> Unit>> = listOf(
        Triple(Icons.Filled.Search, "Chẩn đoán") { showText("Chẩn đoán", "Đang chẩn đoán...") { core.diag() } },
        Triple(Icons.Filled.Menu, "Ứng dụng ngốn RAM") {
            showText("Ứng dụng ngốn RAM", "Đang đọc...") {
                if (Sh.ready) sh("dumpsys meminfo | sed -n '/Total PSS by process/,/^\$/p' | head -n 22").ifBlank { "(không có dữ liệu)" } else NEED
            }
        },
        Triple(Icons.Filled.Phone, "Đo ping") { showText("Đo ping", "Đang đo ping...") { core.ping() } },
        Triple(Icons.Filled.Close, "Dừng ứng dụng") { pick = 1 },
        Triple(Icons.Filled.Settings, "Cài đặt nhanh") { pick = 2 },
        Triple(Icons.Filled.DateRange, "Nhật ký") { dlgT = "Nhật ký"; dlgB = core.readLog() },
        Triple(Icons.Filled.ArrowBack, "Khôi phục gốc") { go("Đang khôi phục...", { ver++ }) { full() }; Unit },
        Triple(Icons.Filled.Build, "Ứng dụng hệ thống thừa") { pick = 3 },
        Triple(Icons.Filled.CheckCircle, "Cấu hình theo RAM") { go("Đang áp dụng cấu hình...", { ver++ }) { applyPreset() }; Unit },
        Triple(Icons.Filled.Lock, "Đăng xuất") { logout("") }
    )

    private fun toggle(f: Fx, on: Boolean): Boolean {
        if (f.pro && !Sh.ready) { toast(NEED); return false }
        val ok = go(if (on) "Đang bật ${f.t}..." else "Đang tắt ${f.t}...") { if (on) f.on() else f.off() }
        if (ok) getSharedPreferences("fx", 0).edit().putBoolean(f.key, on).apply()
        return ok
    }

    private fun play(p: String) {
        if (!installed(p)) { toast("Chưa cài game này"); return }
        go("Đang mở game...", { launch(p) }) { ramClean() }
    }

    private fun shizukuAction() = when (shz.intValue) {
        0 -> packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
            ?: toast("Hãy cài và khởi động Shizuku trước")
        1 -> Shizuku.requestPermission(1)
        else -> toast("Shizuku đã sẵn sàng ✔")
    }

    // ---------- key ----------
    private fun applyRes(r: KeyAuth.Res) {
        lastCheck = System.currentTimeMillis()
        val d = KeyAuth.daysLeft(r)
        info = "Key ••••-${r.key.takeLast(4)} • " + if (d < 0) "Vĩnh viễn" else "Còn $d ngày"
        authMsg = ""; auth = 2
    }

    private fun startAuth() {
        if (!KEY_REQUIRED) { auth = 2; return }
        if ((ap.getString("key", "") ?: "").isEmpty()) { auth = 1; return }
        Thread {
            val r = KeyAuth.auto(this, ap)
            runOnUiThread { if (r.ok) applyRes(r) else { authMsg = r.msg; auth = 1 } }
        }.start()
    }

    private fun doLogin(raw: String) {
        if (loginBusy) return
        loginBusy = true; authMsg = ""
        Thread {
            val r = KeyAuth.login(this, raw)
            if (r.ok) ap.edit().putString("key", r.key).putLong("exp", r.exp).putLong("ok", System.currentTimeMillis()).apply()
            runOnUiThread { loginBusy = false; if (r.ok) applyRes(r) else authMsg = r.msg }
        }.start()
    }

    private fun logout(msg: String) { ap.edit().clear().apply(); authMsg = msg; info = ""; auth = 1 }

    private fun recheck() {
        lastCheck = System.currentTimeMillis()
        Thread {
            val r = KeyAuth.auto(this, ap)
            runOnUiThread { if (r.ok) applyRes(r) else if (r.net) logout(r.msg) }
        }.start()
    }

    // ---------- screens ----------
    @Composable
    fun App() {
        var splash by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) { while (true) { stat = withContext(Dispatchers.IO) { readStat() }; delay(2000) } }
        Box(Modifier.fillMaxSize().background(BG)) {
            if (splash) Splash { splash = false } else when (auth) {
                2 -> Main()
                1 -> LoginScr()
                else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = PUR) }
            }
            busy?.let {
                Box(Modifier.fillMaxSize().background(Color(0xCC000000)).clickable(enabled = true, onClick = {}),
                    contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = PUR); Spacer(Modifier.height(12.dp)); Tx(it, 14)
                    }
                }
            }
            Dialogs()
        }
    }

    @Composable
    fun Dialogs() {
        dlgT?.let { t ->
            AlertDialog(onDismissRequest = { dlgT = null }, containerColor = SURF,
                confirmButton = {
                    Row {
                        if (t == "Nhật ký") TextButton({ core.clearLog(); dlgB = core.readLog() }) { Tx("Xóa nhật ký", 14, DIM) }
                        TextButton({ dlgT = null }) { Tx("Đóng", 14, PUR) }
                    }
                },
                title = { Tx(t, 17, w = FontWeight.Bold) },
                text = {
                    Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                        Text(dlgB, color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                })
        }
        if (pick == 1) {
            val apps = remember { userApps() }
            AlertDialog(onDismissRequest = { pick = 0 }, containerColor = SURF,
                confirmButton = { TextButton({ pick = 0 }) { Tx("Đóng", 14, PUR) } },
                title = { Tx("Chọn ứng dụng để dừng", 17, w = FontWeight.Bold) },
                text = {
                    LazyColumn(Modifier.heightIn(max = 360.dp)) {
                        items(apps) { (label, pkg) ->
                            Tx(label, 14, m = Modifier.fillMaxWidth().pressFx {
                                pick = 0
                                go("Đang dừng $label...") {
                                    if (Sh.ready) sh("am force-stop $pkg")
                                    else (getSystemService(ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(pkg)
                                    "Đã dừng $label"
                                }
                            }.padding(vertical = 10.dp))
                        }
                    }
                })
        }
        if (pick == 3) {
            val apps = remember { sysApps() }
            var dis by remember { mutableStateOf<Set<String>?>(null) }
            LaunchedEffect(Unit) {
                dis = withContext(Dispatchers.IO) { sh("pm list packages -d").lines().map { it.removePrefix("package:").trim() }.toSet() }
            }
            AlertDialog(onDismissRequest = { pick = 0 }, containerColor = SURF,
                confirmButton = { TextButton({ pick = 0 }) { Tx("Đóng", 14, PUR) } },
                title = { Tx("Ứng dụng hệ thống thừa", 17, w = FontWeight.Bold) },
                text = {
                    Column {
                        Tx("Chỉ tắt app bạn chắc chắn không dùng. Bật lại được ngay tại đây hoặc bằng nút Khôi phục gốc.", 12, DIM)
                        val d = dis
                        if (d == null) Tx("Đang tải...", 13, DIM, m = Modifier.padding(top = 12.dp))
                        else LazyColumn(Modifier.heightIn(max = 340.dp).padding(top = 8.dp)) {
                            items(apps) { (label, pkg) ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) { Tx(label, 14); Tx(pkg, 10, DIM) }
                                    Switch(pkg !in d, { on ->
                                        if (!Sh.ready) toast(NEED)
                                        else go("Đang cập nhật...", { dis = if (on) d - pkg else d + pkg }) {
                                            val sp = getSharedPreferences("sysoff", 0).edit()
                                            if (on) { sh("pm enable $pkg"); sp.remove(pkg) }
                                            else { sh("pm disable-user --user 0 $pkg"); sp.putString(pkg, label) }
                                            sp.apply()
                                            if (on) "Đã bật $label" else "Đã tắt $label"
                                        }
                                    }, colors = SwitchDefaults.colors(checkedTrackColor = PUR))
                                }
                            }
                        }
                    }
                })
        }
        if (pick == 2) {
            AlertDialog(onDismissRequest = { pick = 0 }, containerColor = SURF,
                confirmButton = { TextButton({ pick = 0 }) { Tx("Đóng", 14, PUR) } },
                title = { Tx("Mở cài đặt nhanh", 17, w = FontWeight.Bold) },
                text = {
                    Column {
                        listOf("Tiết kiệm pin" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
                            "Màn hình" to Settings.ACTION_DISPLAY_SETTINGS,
                            "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS,
                            "Bộ nhớ trong" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
                            "Quản lý ứng dụng" to Settings.ACTION_APPLICATION_SETTINGS,
                            "Tùy chọn nhà phát triển" to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
                        ).forEach { (n, a) ->
                            Tx(n, 15, m = Modifier.fillMaxWidth().pressFx { pick = 0; openSet(a) }.padding(vertical = 12.dp))
                        }
                    }
                })
        }
    }

    @Composable
    fun LoginScr() {
        var k by remember { mutableStateOf("") }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            Arrangement.Center, Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.logo), null, Modifier.size(150.dp).clip(CircleShape))
            Spacer(Modifier.height(10.dp))
            Tx("KEY SYSTEM", 13, DIM)
            Spacer(Modifier.height(22.dp))
            OutlinedTextField(k, { k = it.uppercase() }, Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Tx("Nhập key của bạn...", 14, DIM) }, shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PUR, unfocusedBorderColor = Color(0x665B21D6),
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = PUR))
            if (authMsg.isNotEmpty()) Tx(authMsg, 13, Color(0xFFF87171), m = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().height(52.dp).pressFx { doLogin(k) }.clip(RoundedCornerShape(26.dp))
                .background(Brush.horizontalGradient(listOf(PUR2, PUR))), contentAlignment = Alignment.Center) {
                if (loginBusy) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                else Tx("Đăng nhập", 16, w = FontWeight.Bold)
            }
            Spacer(Modifier.height(16.dp))
            Tx("Chưa có key? Liên hệ admin", 13, PUR, m = Modifier.pressFx {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(CONTACT_URL))) } catch (e: Exception) { toast("Không mở được liên kết") }
            }.padding(8.dp))
            Spacer(Modifier.height(24.dp))
            Tx("Mã thiết bị: ${KeyAuth.deviceId(this@MainActivity)}", 11, DIM)
            Tx("TSX LAGFIX PRO • Bảo mật - Uy tín - Nhanh chóng", 11, DIM)
        }
    }

    @Composable
    fun Pill() {
        val (t, c) = when (shz.intValue) {
            2 -> "SHIZUKU ●" to Color(0xFF4ADE80)
            1 -> "CẤP QUYỀN" to Color(0xFFFBBF24)
            else -> "BẬT SHIZUKU" to Color(0xFFF87171)
        }
        Box(Modifier.pressFx { shizukuAction() }.clip(RoundedCornerShape(20.dp))
            .border(1.dp, c, RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 6.dp)) {
            Tx(t, 11, c, FontWeight.Bold)
        }
    }

    @Composable
    fun Main() {
        val st = stat
        val prefs = getSharedPreferences("fx", 0)
        var sel by remember { mutableIntStateOf(0) }
        val names = listOf("Free Fire", "Free Fire MAX")
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.logo), null, Modifier.size(44.dp).clip(CircleShape))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("TSX", style = TextStyle(brush = Brush.linearGradient(listOf(Color(0xFFE2CCFF), PUR)),
                            fontSize = 26.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic))
                        Tx("Android ${android.os.Build.VERSION.RELEASE} • ${android.os.Build.MODEL}", 11, DIM)
                        if (info.isNotEmpty()) Tx(info, 11, PUR)
                    }
                    Spacer(Modifier.weight(1f)); Pill()
                }
                Glass(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), Arrangement.SpaceEvenly) {
                        Gauge("RAM", "%.1f GB".format(st.used), "/ %.1f GB".format(st.tot), st.used / st.tot)
                        Gauge("CPU", if (st.cpu < 0) "--" else "${st.cpu}%",
                            if (st.cpu < 0) "Cần Shizuku" else "Sử dụng", if (st.cpu < 0) 0f else st.cpu / 100f)
                        Gauge("HZ", "${st.hz}", "Màn hình", st.hz / (hzList().lastOrNull() ?: st.hz).toFloat())
                    }
                }
                key(ver) {
                    var g = ""
                    fx.forEach { f ->
                        if (f.g != g) { g = f.g; Tx(g, 12, PUR, FontWeight.Bold, Modifier.padding(top = 8.dp)) }
                        FxRow(f.ic, f.t, f.d, prefs.getBoolean(f.key, false)) { on -> toggle(f, on) }
                    }
                }
                Tx("CÔNG CỤ", 12, PUR, FontWeight.Bold, Modifier.padding(top = 8.dp))
                tools.filter { KEY_REQUIRED || it.second != "Đăng xuất" }.chunked(2).forEach { r ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        r.forEach { (ic, t, f) -> ToolTile(ic, t, Modifier.weight(1f), f) }
                        if (r.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
            Column(Modifier.fillMaxWidth().background(SURF).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    names.forEachIndexed { i, n ->
                        GameChip(n, if (installed(FF[i])) "Đã cài đặt" else "Chưa cài", sel == i, Modifier.weight(1f)) { sel = i }
                    }
                }
                val s = RoundedCornerShape(28.dp)
                Box(Modifier.fillMaxWidth().height(56.dp).pressFx { play(FF[sel]) }.clip(s)
                    .background(Brush.horizontalGradient(listOf(SURF_ON, Color(0xFF3B1A78))))
                    .border(1.dp, PUR, s), contentAlignment = Alignment.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.PlayArrow, null, tint = PUR, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(6.dp))
                        Tx("CHƠI ${names[sel].uppercase()}", 16, w = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
