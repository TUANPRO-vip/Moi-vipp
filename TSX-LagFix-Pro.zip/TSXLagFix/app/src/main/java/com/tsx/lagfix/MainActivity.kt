package com.tsx.lagfix

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.ContentResolver
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import rikka.shizuku.Shizuku

private val BG = Color(0xFF07040F)
private val SURF = Color(0xFF140B28)
private val PUR = Color(0xFF9B5CFF)
private val PUR2 = Color(0xFF5B21D6)
private val DIM = Color(0xFFA99BC8)
private const val NEED = "Cần bật Shizuku để dùng tính năng này"
private val FF = listOf("com.dts.freefireth", "com.dts.freefiremax")

data class Stat(val used: Float, val tot: Float, val cpu: Int, val hz: Int)

// ================= UI components =================
@Composable
fun Tx(s: String, sz: Int = 14, c: Color = Color.White, w: FontWeight = FontWeight.Normal,
       m: Modifier = Modifier, a: TextAlign? = null) =
    Text(s, m, color = c, fontSize = sz.sp, fontWeight = w, textAlign = a)

@Composable
fun Glass(m: Modifier = Modifier, f: (() -> Unit)? = null, c: @Composable BoxScope.() -> Unit) {
    val s = RoundedCornerShape(16.dp)
    var mm = m.clip(s).background(SURF).border(1.dp, Brush.linearGradient(listOf(PUR, Color(0x335B21D6))), s)
    if (f != null) mm = mm.clickable { f() }
    Box(mm, content = c)
}

@Composable
fun Primary(t: String, f: () -> Unit) = Box(
    Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(28.dp))
        .background(Brush.horizontalGradient(listOf(PUR2, PUR))).clickable { f() },
    contentAlignment = Alignment.Center
) { Tx(t, 16, w = FontWeight.Bold) }

@Composable
fun Gauge(label: String, big: String, small: String, frac: Float) {
    Box(Modifier.size(92.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = 8.dp.toPx()
            val tl = Offset(w / 2, w / 2)
            val sz = Size(size.width - w, size.height - w)
            drawArc(Color(0x33FFFFFF), 135f, 270f, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
            drawArc(Brush.linearGradient(listOf(PUR2, PUR)), 135f, 270f * frac.coerceIn(0f, 1f), false, tl, sz,
                style = Stroke(w, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Tx(label, 10, DIM); Tx(big, 17, w = FontWeight.Bold); Tx(small, 9, DIM)
        }
    }
}

@Composable
fun Tile(ic: String, t: String, m: Modifier, f: () -> Unit) = Glass(m.height(88.dp), f) {
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Tx(ic, 24); Tx(t, 12, m = Modifier.padding(top = 4.dp), a = TextAlign.Center)
    }
}

@Composable
fun Item(ic: String, t: String, d: String, f: () -> Unit) = Glass(Modifier.fillMaxWidth(), f) {
    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0x339B5CFF)), contentAlignment = Alignment.Center) { Tx(ic, 20) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Tx(t, 15, w = FontWeight.SemiBold); Tx(d, 12, DIM) }
        Tx("›", 24, DIM)
    }
}

@Composable
fun Chips(opts: List<String>, sel: Int, pick: (Int) -> Unit) =
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        opts.forEachIndexed { i, s ->
            Box(Modifier.clip(RoundedCornerShape(10.dp))
                .background(if (i == sel) PUR else Color(0x229B5CFF))
                .clickable { pick(i) }.padding(horizontal = 12.dp, vertical = 7.dp)) { Tx(s, 12) }
        }
    }

@Composable
fun Tog(t: String, init: Boolean, f: (Boolean) -> Unit) {
    var v by remember { mutableStateOf(init) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Tx(t, 14, m = Modifier.weight(1f))
        Switch(v, { v = it; f(it) }, colors = SwitchDefaults.colors(checkedTrackColor = PUR))
    }
}

@Composable
fun Splash(done: () -> Unit) {
    var s by remember { mutableStateOf(false) }
    val p by animateFloatAsState(if (s) 1f else 0f, tween(1700), label = "p")
    LaunchedEffect(Unit) { s = true; delay(2000); done() }
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(270.dp).clip(CircleShape))
        Spacer(Modifier.height(18.dp))
        Tx("TỐI ƯU - MƯỢT MÀ - CHIẾN THẮNG", 12, DIM)
        Spacer(Modifier.height(28.dp))
        Tx("Đang khởi động...", 13, PUR)
        Spacer(Modifier.height(8.dp))
        Box(Modifier.width(220.dp).height(4.dp).clip(CircleShape).background(Color(0x33FFFFFF))) {
            Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(Brush.horizontalGradient(listOf(PUR2, PUR))))
        }
    }
}

// ================= Activity =================
class MainActivity : ComponentActivity() {
    private val shz = mutableIntStateOf(0) // 0 chưa chạy, 1 cần cấp quyền, 2 sẵn sàng
    private var screen by mutableStateOf("home")
    private var busy by mutableStateOf<String?>(null)
    private var hzDlg by mutableStateOf(false)
    private var stat by mutableStateOf(Stat(0f, 1f, -1, 60))
    private var prevT = 0L
    private var prevI = 0L
    private var binding = false

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            Sh.svc = IUserService.Stub.asInterface(b); shz.intValue = 2
        }
        override fun onServiceDisconnected(n: ComponentName?) { Sh.svc = null; binding = false; shz.intValue = 1 }
    }
    private val onBinder = Shizuku.OnBinderReceivedListener { check() }
    private val onDead = Shizuku.OnBinderDeadListener { Sh.svc = null; binding = false; shz.intValue = 0 }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> check() }

    private fun check() {
        if (!Shizuku.pingBinder()) { shz.intValue = 0; return }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { shz.intValue = 1; return }
        if (Sh.svc == null && !binding) {
            binding = true
            Shizuku.bindUserService(
                Shizuku.UserServiceArgs(ComponentName(packageName, UserService::class.java.name))
                    .processNameSuffix("sh").version(1).daemon(false), conn)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
        setContent { App() }
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
    }

    // ---------- helpers ----------
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun sh(c: String) = Sh.run(c)

    private fun go(label: String, after: (() -> Unit)? = null, f: () -> String) {
        if (busy != null) return
        busy = label
        Thread {
            val r = try { f() } catch (e: Exception) { "Lỗi: ${e.message}" }
            runOnUiThread { busy = null; toast(r); after?.invoke() }
        }.start()
    }
    private fun pro(label: String, f: () -> String) = go(label) { if (Sh.ready) f() else NEED }

    private fun installed(p: String) = packageManager.getLaunchIntentForPackage(p) != null
    private fun launch(p: String) =
        packageManager.getLaunchIntentForPackage(p)?.let { startActivity(it) } ?: toast("Chưa cài game này")

    private fun hzList(): List<Int> =
        windowManager.defaultDisplay.supportedModes.map { it.refreshRate.roundToInt() }.distinct().sorted()

    private fun availMb(): Long {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.availMem shr 20
    }

    private fun cpuPct(): Int {
        if (!Sh.ready) return -1
        val f = sh("head -1 /proc/stat").trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (f.size < 5) return -1
        val t = f.take(8).sum(); val i = f[3] + f[4]
        val r = if (prevT == 0L || t == prevT) 0 else (100 - (i - prevI) * 100 / (t - prevT)).toInt()
        prevT = t; prevI = i
        return r.coerceIn(0, 100)
    }

    private fun readStat(): Stat {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val g = 1024f * 1024f * 1024f
        return Stat((mi.totalMem - mi.availMem) / g, mi.totalMem / g, cpuPct(),
            windowManager.defaultDisplay.refreshRate.roundToInt())
    }

    // ---------- engine ----------
    private fun killBgApi() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName }.distinct().filter { it != packageName }
            .forEach { am.killBackgroundProcesses(it) }
    }

    private fun ramClean(): String {
        val a = availMb()
        if (Sh.ready) sh("am kill-all; pm trim-caches 999G") else killBgApi()
        Thread.sleep(900)
        return "Đã giải phóng ~${maxOf(0, availMb() - a)} MB RAM" + if (Sh.ready) " + dọn cache" else ""
    }

    private fun killApps(): String {
        if (!Sh.ready) { killBgApi(); return "Đã tắt app nền (cơ bản). Bật Shizuku để tắt sâu hơn" }
        val ime = Settings.Secure.getString(contentResolver, "default_input_method")?.substringBefore('/')
        val home = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName
        val keep = (listOfNotNull(packageName, "moe.shizuku.privileged.api", ime, home) + FF).joinToString("|")
        sh("for p in \$(pm list packages -3 | cut -d: -f2); do case \$p in $keep) ;; *) am force-stop \$p;; esac; done; am kill-all")
        return "Đã tắt ứng dụng chạy nền"
    }

    private fun lockHz(hz: Int): String {
        sh("settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz")
        return "Đã khóa ${hz}Hz (tùy máy hỗ trợ)"
    }

    private fun boostFps(): String {
        val c = StringBuilder("settings put global low_power 0;")
        FF.forEach {
            c.append("cmd game mode performance $it; am set-standby-bucket $it active;")
            c.append("dumpsys deviceidle whitelist +$it; cmd appops set $it RUN_ANY_IN_BACKGROUND allow;")
        }
        sh(c.toString())
        lockHz(hzList().last())
        return "Đã bật chế độ hiệu năng cao cho Free Fire"
    }

    private fun dropFps(): String {
        sh("am kill-all; pm trim-caches 999G; settings put global low_power 0;" +
            "settings put global window_animation_scale 0.5; settings put global transition_animation_scale 0.5;" +
            "settings put global animator_duration_scale 0.5")
        try { ContentResolver.setMasterSyncAutomatically(false) } catch (e: Exception) {}
        return "Đã giảm tải hệ thống, hạn chế tụt khung hình"
    }

    private fun ramOpt(): String {
        val c = StringBuilder("am kill-all;")
        FF.forEach { c.append("am set-standby-bucket $it active; dumpsys deviceidle whitelist +$it;") }
        sh(c.toString())
        return "Đã ưu tiên tài nguyên cho Free Fire"
    }

    private fun deep(): String {
        val ins = FF.filter { installed(it) }
        if (ins.isEmpty()) return "Chưa cài Free Fire"
        ins.forEach { sh("cmd package compile -m speed -f $it") }
        return "Đã tối ưu sâu mã game (ART)"
    }

    private fun setRes(pct: Int): String {
        if (pct >= 100) { sh("wm size reset"); return "Đã khôi phục độ phân giải" }
        val m = Regex("(\\d+)x(\\d+)").find(sh("wm size")) ?: return "Không đọc được độ phân giải"
        val w = m.groupValues[1].toInt(); val h = m.groupValues[2].toInt()
        sh("wm size ${w * pct / 100 / 2 * 2}x${h * pct / 100 / 2 * 2}")
        return "Đã đặt độ phân giải $pct%"
    }

    private fun resetAll(): String {
        sh("wm size reset; settings delete system min_refresh_rate; settings delete system peak_refresh_rate;" +
            "settings put global window_animation_scale 1; settings put global transition_animation_scale 1;" +
            "settings put global animator_duration_scale 1; cmd notification set_dnd off;" +
            "svc bluetooth enable; svc nfc enable")
        return "Đã khôi phục cài đặt mặc định"
    }

    private fun aBoost() = pro("Đang tăng FPS...") { boostFps() }
    private fun aDrop() = pro("Đang giảm drop FPS...") { dropFps() }
    private fun aRam() = go("Đang dọn RAM...") { ramClean() }
    private fun aOpt() = pro("Đang tối ưu RAM...") { ramOpt() }
    private fun aKill() = go("Đang tắt ứng dụng nền...") { killApps() }
    private fun aDeep() = pro("Đang tối ưu sâu (1-3 phút)...") { deep() }
    private fun aAll() = go("Đang tối ưu toàn bộ...", { screen = "game" }) {
        ramClean(); killApps()
        if (Sh.ready) { dropFps(); boostFps(); ramOpt(); "Hoàn tất tối ưu ✔" }
        else "Đã tối ưu cơ bản. Bật Shizuku để tối ưu sâu"
    }

    private fun shizukuAction() = when (shz.intValue) {
        0 -> packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
            ?: toast("Hãy cài và khởi động Shizuku trước")
        1 -> Shizuku.requestPermission(1)
        else -> toast("Shizuku đã sẵn sàng ✔")
    }

    // ---------- screens ----------
    @Composable
    fun App() {
        var splash by remember { mutableStateOf(true) }
        BackHandler(!splash && screen != "home") { screen = "home" }
        LaunchedEffect(Unit) { while (true) { stat = withContext(Dispatchers.IO) { readStat() }; delay(2000) } }
        Box(Modifier.fillMaxSize().background(BG)) {
            if (splash) Splash { splash = false } else Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f)) {
                    when (screen) {
                        "lag" -> Lag(); "set" -> SettingsScr(); "game" -> GameScr(); "about" -> About()
                        else -> Home()
                    }
                }
                if (screen in listOf("home", "lag", "set")) Nav()
            }
            busy?.let {
                Box(Modifier.fillMaxSize().background(Color(0xCC000000)).clickable(enabled = true, onClick = {}),
                    contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = PUR); Spacer(Modifier.height(12.dp)); Tx(it, 14)
                    }
                }
            }
            if (hzDlg) AlertDialog(
                onDismissRequest = { hzDlg = false }, confirmButton = {}, containerColor = SURF,
                title = { Tx("Khóa tần số quét", 17, w = FontWeight.Bold) },
                text = {
                    val l = hzList()
                    Chips(l.map { "${it}Hz" }, -1) { i -> hzDlg = false; pro("Đang khóa ${l[i]}Hz...") { lockHz(l[i]) } }
                })
        }
    }

    @Composable
    fun Nav() = Row(Modifier.fillMaxWidth().background(SURF).padding(vertical = 8.dp), Arrangement.SpaceEvenly) {
        listOf(Triple("home", "🏠", "Trang chủ"), Triple("lag", "⚡", "Lag quản")).forEach { (k, i, t) ->
            Column(Modifier.clickable { screen = k }.padding(horizontal = 28.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Tx(i, 20); Tx(t, 11, if (screen == k) PUR else DIM)
            }
        }
    }

    @Composable
    fun Pill() {
        val (t, c) = when (shz.intValue) {
            2 -> "SHIZUKU ●" to Color(0xFF4ADE80)
            1 -> "CẤP QUYỀN" to Color(0xFFFBBF24)
            else -> "BẬT SHIZUKU" to Color(0xFFF87171)
        }
        Box(Modifier.clip(RoundedCornerShape(20.dp)).border(1.dp, c, RoundedCornerShape(20.dp))
            .clickable { shizukuAction() }.padding(horizontal = 12.dp, vertical = 6.dp)) { Tx(t, 11, c, FontWeight.Bold) }
    }

    @Composable
    fun Page(content: @Composable ColumnScope.() -> Unit) = Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content)

    @Composable
    fun Back(t: String) = Row(Modifier.clickable { screen = "home" }, verticalAlignment = Alignment.CenterVertically) {
        Tx("←", 24); Spacer(Modifier.width(12.dp)); Tx(t, 19, w = FontWeight.Bold)
    }

    @Composable
    fun Home() = Page {
        val st = stat
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("TSX", style = TextStyle(brush = Brush.linearGradient(listOf(Color(0xFFE2CCFF), PUR)),
                fontSize = 32.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic))
            Spacer(Modifier.weight(1f)); Pill(); Spacer(Modifier.width(12.dp))
            Tx("⚙", 24, m = Modifier.clickable { screen = "set" })
        }
        Glass(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo), null, Modifier.size(64.dp).clip(CircleShape))
                Spacer(Modifier.width(12.dp))
                Column {
                    Tx("TSX LAGFIX PRO", 17, w = FontWeight.Bold)
                    Tx("Tối ưu hiệu năng • Giảm lag • Giảm tụt FPS", 11, DIM)
                    Tx("Free Fire • Android ${Build.VERSION.RELEASE} • ${Build.MODEL}", 11, DIM)
                }
            }
        }
        Glass(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), Arrangement.SpaceEvenly) {
                Gauge("RAM", "%.1f GB".format(st.used), "/ %.1f GB".format(st.tot), st.used / st.tot)
                Gauge("CPU", if (st.cpu < 0) "--" else "${st.cpu}%", if (st.cpu < 0) "Cần Shizuku" else "Sử dụng",
                    if (st.cpu < 0) 0f else st.cpu / 100f)
                Gauge("HZ", "${st.hz}", "Màn hình", st.hz / (hzList().lastOrNull() ?: st.hz).toFloat())
            }
        }
        Primary("⚡  BẮT ĐẦU TỐI ƯU") { aAll() }
        val tiles: List<Triple<String, String, () -> Unit>> = listOf(
            Triple("🚀", "Tăng FPS") { aBoost() }, Triple("🎮", "Giảm Lag") { aDrop() },
            Triple("🗑️", "Dọn RAM") { aRam() }, Triple("🔒", "Khóa FPS") { hzDlg = true },
            Triple("🔲", "Tối ưu RAM") { aOpt() }, Triple("⚙️", "Cài đặt nâng cao") { screen = "set" })
        tiles.chunked(3).forEach { r ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                r.forEach { (i, t, f) -> Tile(i, t, Modifier.weight(1f), f) }
            }
        }
    }

    @Composable
    fun Lag() = Page {
        Tx("⚡  Lag Quản", 20, w = FontWeight.Bold)
        Item("🚀", "Tăng FPS", "Giúp game mượt hơn, ổn định hơn") { aBoost() }
        Item("🎮", "Giảm Drop FPS", "Hạn chế tụt khung hình") { aDrop() }
        Item("🔒", "Khóa FPS", "Giữ tần số quét ổn định theo mức đặt") { hzDlg = true }
        Item("🗑️", "Dọn RAM", "Giải phóng bộ nhớ, giảm lag") { aRam() }
        Item("🔲", "Tối ưu RAM", "Ưu tiên RAM cho game") { aOpt() }
        Item("⚙️", "Tắt ứng dụng chạy nền", "Giảm tải hệ thống, tăng hiệu suất") { aKill() }
        Glass(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(PUR2, SURF))), { aDeep() }) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Tx("👑", 28); Spacer(Modifier.width(12.dp))
                Column { Tx("TSX PRO", 16, w = FontWeight.Bold); Tx("Tối ưu sâu mã game (ART) - hiệu quả hơn", 12, DIM) }
            }
        }
    }

    @Composable
    fun SettingsScr() = Page {
        val hz = hzList()
        var rs by remember { mutableIntStateOf(0) }
        var hs by remember { mutableIntStateOf(-1) }
        val nm = getSystemService(NotificationManager::class.java)
        Tx("⚙  Cài đặt", 20, w = FontWeight.Bold)
        Tx("Tối ưu hệ thống", 13, PUR, FontWeight.Bold)
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Tog("Tắt tự động sáng", Settings.System.getInt(contentResolver, "screen_brightness_mode", 1) == 0) { on ->
                    pro("Đang áp dụng...") { sh("settings put system screen_brightness_mode ${if (on) 0 else 1}"); "Đã cập nhật" }
                }
                Tog("Tắt thông báo (Không làm phiền)", nm.currentInterruptionFilter in 2..4) { on ->
                    pro("Đang áp dụng...") { sh("cmd notification set_dnd ${if (on) "priority" else "off"}"); "Đã cập nhật" }
                }
                Tog("Giảm hiệu ứng hệ thống",
                    Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) < 1f) { on ->
                    val v = if (on) "0.5" else "1"
                    pro("Đang áp dụng...") {
                        sh("settings put global window_animation_scale $v; settings put global transition_animation_scale $v;" +
                            "settings put global animator_duration_scale $v"); "Đã cập nhật"
                    }
                }
                Tog("Tắt dịch vụ không cần thiết (BT, NFC, đồng bộ)", false) { on ->
                    pro("Đang áp dụng...") {
                        sh("svc bluetooth ${if (on) "disable" else "enable"}; svc nfc ${if (on) "disable" else "enable"}")
                        try { ContentResolver.setMasterSyncAutomatically(!on) } catch (e: Exception) {}
                        "Đã cập nhật"
                    }
                }
            }
        }
        Tx("Tùy chỉnh game", 13, PUR, FontWeight.Bold)
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Tx("Độ phân giải hiển thị (giảm tải GPU)", 14)
                Chips(listOf("Tự động", "90%", "80%", "70%"), rs) { i ->
                    rs = i; val p = intArrayOf(100, 90, 80, 70)[i]; pro("Đang áp dụng...") { setRes(p) }
                }
                Tx("FPS trong game (khóa tần số quét)", 14)
                Chips(hz.map { "${it}Hz" }, hs) { i -> hs = i; pro("Đang áp dụng...") { lockHz(hz[i]) } }
            }
        }
        Primary("Khôi phục mặc định") { pro("Đang khôi phục...") { resetAll() } }
        Tx("Giới thiệu về TSX LagFix Pro", 13, DIM, m = Modifier.clickable { screen = "about" }.padding(8.dp))
    }

    @Composable
    fun GameScr() = Page {
        var sel by remember { mutableIntStateOf(0) }
        val gs = listOf("Free Fire Thường" to FF[0], "Free Fire Max" to FF[1])
        Row(Modifier.clickable { screen = "home" }, verticalAlignment = Alignment.CenterVertically) {
            Tx("←", 24); Spacer(Modifier.width(12.dp)); Tx("Khởi động game", 19, w = FontWeight.Bold)
        }
        Box(Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF2A0F5C), PUR2))), contentAlignment = Alignment.Center) {
            Tx("FREE FIRE", 36, w = FontWeight.Black)
        }
        gs.forEachIndexed { i, (n, p) ->
            Glass(Modifier.fillMaxWidth(), { sel = i }) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(sel == i, { sel = i }, colors = RadioButtonDefaults.colors(selectedColor = PUR))
                    Column { Tx(n, 15, w = FontWeight.SemiBold); Tx(if (installed(p)) "Đã cài đặt" else "Chưa cài", 12, DIM) }
                }
            }
        }
        Primary("🚀  Bắt đầu game") {
            val p = gs[sel].second
            go("Đang tối ưu & mở game...", { launch(p) }) { ramClean(); if (Sh.ready) { boostFps(); "Sẵn sàng ✔" } else "Đã tối ưu cơ bản" }
        }
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Tx("Lưu ý:", 13, w = FontWeight.Bold)
                Tx("• Đã tối ưu trước khi vào game", 12, DIM)
                Tx("• Đảm bảo còn đủ dung lượng RAM", 12, DIM)
                Tx("• Đóng ứng dụng không cần thiết", 12, DIM)
            }
        }
    }

    @Composable
    fun About() = Page {
        Back("Giới thiệu")
        Image(painterResource(R.drawable.logo), null, Modifier.size(170.dp).clip(CircleShape).align(Alignment.CenterHorizontally))
        Tx("TSX LAGFIX PRO", 20, w = FontWeight.Bold, m = Modifier.fillMaxWidth(), a = TextAlign.Center)
        Tx("Phiên bản: 1.0.0", 13, DIM, m = Modifier.fillMaxWidth(), a = TextAlign.Center)
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Tx("🚀  Tối ưu FPS - Giảm lag", 14); Tx("🤖  Hỗ trợ mọi dòng Android 8+", 14)
                Tx("🎮  Tương thích Free Fire / Free Fire Max", 14); Tx("🛡  Bảo mật thông tin", 14)
            }
        }
        Tx("Cùng TSX - Chiến game mượt mà!", 13, PUR, FontWeight.Bold, Modifier.fillMaxWidth(), TextAlign.Center)
    }
}
