package com.tsx.lagfix

object Sh {
    @Volatile var svc: IUserService? = null
    val ready get() = svc != null
    fun run(c: String): String = try { svc?.exec(c) ?: "" } catch (e: Exception) { "" }
}
